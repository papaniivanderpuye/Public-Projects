To start up the program
1. go into the ResPro package folder
2. open a terminal in that directory



3.type and run this:
~$ python3 main-create-training-data.py


4.program will ask whether you want to generate training data files,(this takes a long time). If files hae already been made you can just press enter.

5.Program will then it will ask what you want to do, follow program instructions. All tasks except AAC will take a good amount of time to execute.

6. After you press 'q' to quit the program, it will ask whether you want to delete all created files for the training and testing. (These files take up a lot of space, and so if you do not intend to run the code again, you should delete them)




