package com.example.loaner.mario;

import android.graphics.Bitmap;

/**
 * Created by loaner on 4/18/17.
 */

public class Mario extends Sprite{

    public Mario(GameView gameView, Bitmap bmp) {
        super(gameView, bmp);
    }
}
